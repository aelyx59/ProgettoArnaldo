package it.unibs.fdp.planetarium;

import java.util.regex.Pattern;

//abstract class for cover celestial where cover celestial are Star, Planet, Moon
public abstract class CorpoCeleste {
	private String id;
	private double weight;
	private Coordinate position;
	
	//constructor method
	public CorpoCeleste(String id, Coordinate position, double weight) {
		this.id = id;
		this.weight = weight;
		this.position = position; 
	}	
	
	//abstract methods 
	public abstract void append();
	public abstract void remove();
	public abstract String toString();
	public abstract double getMassaParziale();
	public abstract Coordinate getCoordinatePesateParziale();
	public abstract String search(String id);
	
	public String getInfo() {
		return this.id + ": massa = " + this.weight + "; pos = (" + String.format("%.2f", this.position.getX()) + "; " + String.format("%.2f", this.position.getY()) + ")";
	}
	
	//get the weighted coordinates 
	public Coordinate getCoordinatePesate() {
		return new Coordinate(position.getX()*weight, position.getY()*weight);
	}
	
	public static boolean validateName(String id) {
		int counter = 0;
		for(int i = 0; i < id.length(); i++) 
			if(id.charAt(i) == '_')
				counter ++;
		if (counter > 2) return false;		
		
		String[] parts = id.split("_");
		
		switch(parts.length) {
		case 1: return validatePart(parts[0], "ST");
		
		case 2: return validatePart(parts[0], "ST") && validatePart(parts[1], "P");
		
		case 3: return validatePart(parts[0], "ST") && validatePart(parts[1], "P") && validatePart(parts[2], "LUN");
			
		default: return false;
			
		}
	}
	
	public static boolean validatePart(String idPart, String correctLetters) {
		int numIndex = -1;
		
		for (int i = 0; i < idPart.length() && numIndex == -1;  i++) 
			if(Character.isDigit(idPart.charAt(i))) 
				numIndex = i;
		
		if(numIndex == -1) 
			return false;
		
		String letters = idPart.substring(0, numIndex);
		String numbers = idPart.substring(numIndex);
		
		return letters.equals(correctLetters) && Pattern.matches("[0-9]", numbers);
				
	}
	
	//getters
	public String getId() {
		return id;
	}

	public double getWeight() {
		return weight;
	}

	public Coordinate getPosition() {
		return position;
	}
	
}