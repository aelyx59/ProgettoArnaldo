package it.unibs.fdp.planetarium;

public class Luna extends CorpoCeleste{ 
	
	public Luna(String id, Coordinate position, double weight) {
		super(id, position, weight);
	}
	
	@Override
	public void append() {
		System.out.println("Nulla da aggiungere");
		
	}

	@Override
	public void remove() {
		System.out.println("Nulla da rimuovere");
		
	}

	@Override
	public String toString() {
		return this.getId().replace('_', '>'); 				
	}

	@Override
	public String search(String id) {
		// 'not to used' method
		return null;
	}

	@Override
	public double getMassaParziale() {
		// not used method
		return 0;
	}

	@Override
	public Coordinate getCoordinatePesateParziale() {
		// TODO Auto-generated method stub
		return null;
	}

}
