package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;


public class Pianeta extends CorpoCeleste{
	private static int countermoon = 0;
	private ArrayList<Luna> lune = new ArrayList<Luna>();
	
	public Pianeta(String id, Coordinate position, double weight) {
		super(id, position,weight);
		
	}
	
	public ArrayList<Luna> getLune() {
		return lune; 
	}
	
	public Luna getLuna(int index) {
		return lune.get(index);
	}
	
	@Override
	public double getMassaParziale() {
		double massparz = 0;
		
		for(Luna lun: lune)  {
			massparz += lun.getWeight();		
		}			
		
		return massparz;
	}
	
	@Override
	public Coordinate getCoordinatePesateParziale() {
		Coordinate coordsPesateParz = new Coordinate(0,0);
		
		for(Luna lun: lune)  {
			Coordinate coordsPesateLun = lun.getCoordinatePesate();
			coordsPesateParz.setX(coordsPesateParz.getX() + coordsPesateLun.getX());
			coordsPesateParz.setY(coordsPesateParz.getY() + coordsPesateLun.getY());
		}			
		
		return coordsPesateParz;
		
	}

	
	@Override
	public void append() {
		if(lune.size() >= 5000) {
			System.out.println("Numero massimo di lune raggiunto ");
		}
		
		String id = this.getId() + "_" + "LUN"+ countermoon;
		countermoon ++;
		
		Coordinate position = Coordinate.input("Inserisci la posizione di" + id + "(sintassi 1.0;2.3): ");
		double weight = InputDati.leggiDoubleConMinimo("Inserisci la massa di" + id + "(min: 0,25): ", 0.25);
		
		lune.add(new Luna(id, position, weight));
		
	} 

	@Override
	public void remove() {
		//Input dell'id
		String id = InputDati.leggiStringa("Inserisci l'ID della luna da rimuovere: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID non valido");
			return;		
		}			
		
		int index = -1;
		
		//searching the index of the moon
		index = Integer.parseInt(search(id));
		
		if(index != -1) {
			lune.remove(index);
			System.out.println("La luna � stata rimossa correttamente");
		} 
		else 
			System.out.println("Error404: Luna not found! ");
			
	}

	@Override
	public String toString() {
		String str = "";
		for(Luna lun: lune) {
			str += lun.getId() + "in posizione" + lun.getPosition() + "\n" ;
		}
		return str;
	}

	public String printLune() {
		String str = "";
		
		for(Luna lun: lune) {
			str += lun.getId() + " ";
		}
		
		return str;
	}
	
	
	@Override
	public String search(String id) {
		int index = -1;
		
		for (Luna lun: lune) {
			System.out.println(lun);
			if(id.equals(lun.getId())) {
				index = lune.indexOf(lun);
			}
		}
		return "" + index; 
		
	}

}
