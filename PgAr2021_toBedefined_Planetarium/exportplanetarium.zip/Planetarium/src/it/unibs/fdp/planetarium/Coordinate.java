package it.unibs.fdp.planetarium;

import java.util.regex.Pattern;

import it.unibs.fp.mylib.InputDati;

public class Coordinate {
	private double x;
	private double y;
	
	public Coordinate(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	//Syntax = (x,y) and we put x = 1.0 and y = 2.0
	public static Coordinate input(String messaggio) {
		
		String coordinate;
		boolean finito = false;
		
		do {
			coordinate = InputDati.leggiStringa(messaggio).replace(',', '.');
			
			if(validateCoordinate(coordinate))
				finito = true;
			else 
				System.out.println("Errore di sintassi");
			
			
		} while(!finito);
		 
		
		String[] parts = coordinate.split(";");
		
		
		
		double x = Double.parseDouble(parts[0]);
		double y = Double.parseDouble(parts[1]);
		
		return new Coordinate(x,y); 
			
	}

	public static boolean validateCoordinate(String str) {
		String[] parts = str.split(";"); 
		if(parts.length != 2) 
			return false;
		return Pattern.matches("^[-+]?[0-9]+([,|.][0-9]+)?$",parts[0]) && Pattern.matches("^[-+]?[0-9]+([,|.][0-9]+)?$",parts[1]);
	}
	
	
	@Override
	public String toString() {
		return "[" + String.format("%.3f", x) + "; " + String.format("%.3f", y) + "]"; 
	}

}
