package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;

public class Database {
	private ArrayList<Sistema> sistemi;

	public Database() {
		sistemi = new ArrayList<Sistema>();
	}
	
	public ArrayList<Sistema> getSistemi() {
		return sistemi;
	}

	public Sistema getSistema(int index) {
		return sistemi.get(index); 
	}

	public void inputSistema() {
		sistemi.add(new Sistema());
		System.out.println("\r\nStella creata con successo\r\n");
	}

	public void inputPianeti() {
		int index = selectSistema();
		
		if (index == -1) {
			return;
		}
		
		sistemi.get(index).getStella().append();
		
		System.out.println("\r\nPianeta creato con successo\r\n");
		}

	public void inputLune() {
		int indexSistema = selectSistema(); 
		
		if (indexSistema == -1) {
			return;
		}
		
		int indexPianeta = selectPianeta(indexSistema);
		
		if(indexPianeta == -1) {
			return;
		}	
		
		sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).append();
	
		System.out.println("\r\nLuna creata con successo\r\n");
	}	
	
	public void removeSistema() {
		int index = selectSistema();
		
		if (index == -1) {
			return;
		}
		
		sistemi.remove(index);
		
		System.out.println("\r\nStella distrutta con successo\r\n");
		
	}

	public void removePianeti() {
		int indexSistema = selectSistema();
		
		if (indexSistema == -1) {
			return;
		}
		
		int indexPianeta = selectPianeta(indexSistema);
		
		if(indexPianeta == -1) {
			return;
		}
		
		sistemi.get(indexSistema).getStella().getPianeti().remove(indexPianeta);
		
		System.out.println("\r\nPianeta distrutto con successo\r\n");
		
	}

	public void removeLuna() {
		int indexSistema = selectSistema();
		
		if (indexSistema == -1) {
			return;
		}
		
		int indexPianeta = selectPianeta(indexSistema);
		
		if(indexPianeta == -1) {
			return;
		}
		
		int indexLuna = selectLuna(indexSistema, indexPianeta);
			
		if(indexLuna == -1) {
			return;
			}
		
		sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).getLune().remove(indexLuna);
		
		System.out.println("\r\nLuna distrutta con successo\r\n");
		
	} 
	

	public int selectSistema() {
		if(sistemi.size() < 1) {
			System.out.println("Devi creare un stella\r\n");
			return -1;
		}
		
		System.out.println("Scegli un sistema tra i seguenti: " + printSistemi());
		
		String id = InputDati.leggiStringa("Scelta: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID selezionato non valido");
			return -1;
		}
		
		int index = searchSistema(id);
		if(index == -1) {
			System.out.println("Sistema non trovato!\r\n");
			return -1;
		}
		
		return index;
	}	
				

	public String printSistemi() {
		String str = "";
		for(Sistema sist: sistemi) 
			str += sist.getStella().getId() + " ";
		
		return str;
				
	}
	
	
	public int selectPianeta(int indexSistema) {
		
		Stella st = sistemi.get(indexSistema).getStella();
		
		if(st.getPianeti().size() < 1) {
			System.out.println("Devi creare un pianeta\r\n");
			return -1;
		}
		
		System.out.println("Scegli un pianeta tra i seguenti: " + st.printPianeti());
		
		String id = InputDati.leggiStringa("Scelta: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID selezionato non valido");
			return -1;
		}
		
		int index = Integer.parseInt(st.search(id));
		if(index == -1) {
			System.out.println("Pianeta non trovato!\r\n");
			return -1;
		}
		
		return index;
	}
	
	public int selectLuna(int indexSistema, int indexPianeta) {
		
		Pianeta p = sistemi.get(indexSistema).getStella().getPianeta(indexPianeta);
		
		if(p.getLune().size() < 1) {
			System.out.println("Devi creare una Luna\r\n");
			return -1;
		}
		
		System.out.println("Scegli una luna tra le seguente: " + p.printLune());
		
		String id = InputDati.leggiStringa("Scelta: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID selezionato non valido");
			return -1;
		}
		
		int index = Integer.parseInt(p.search(id));
		if(index == -1) {
			System.out.println("Luna non trovata!\r\n");
			return -1;
		}
		
		return index;
	}
	
 	
	
	
	
	public void visualizza() {
		int selezionato = 1;
		int scelta = 0;
		int indexSistema = -1;
		int indexPianeta = -1;
		int indexLuna = -1;
		
		System.out.println("\r\nVISUALIZZZIONE DEI SISTEMI");
		
		do {
			System.out.println();
			switch(selezionato) {
			
			//star
			case 1:
				indexSistema = selectSistema();
				if(indexSistema == -1) break;
				System.out.println("> " + sistemi.get(indexSistema).getStella().getInfo());
				selezionato = 2;
				break;
				
			//planet
			case 2:
				if(indexSistema != -1) {
					indexPianeta = selectPianeta(indexSistema);
					if(indexPianeta == -1) break;
					System.out.println("> " + sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).getInfo());
					selezionato = 3;					
				}
				break;
				
			//moon	
			case 3:
				if(indexSistema != -1 && indexPianeta != -1) {
					indexLuna = selectLuna(indexSistema, indexPianeta);
					if(indexLuna == -1) break;
					System.out.println("> " + sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).getInfo());
				}
				break;
			
			//exit
			case 0: break;
			
			//error
			default: System.out.println("Inserisci un numero valido");
			
			} 
			
			//choices menu
			do {
				scelta = InputDati.leggiIntero("\r\n**Cosa vuoi fare (torna al menu[0], indietro[1], prosegui[any other number]): ");
				if(scelta == 1 && selezionato > 1) 
					selezionato --;
				
			} while (scelta == 1);			
			
			
		} while(scelta != 0);
		
		
	}
	
	public void ricerca() {
		System.out.println("\r\nINSERISCI L'ID DEL CORPO CELESTE DA RICERCARE");
		
		String id = InputDati.leggiStringa("Scelta: ").toUpperCase().trim();
		if (!CorpoCeleste.validateName(id)) {
			System.out.println("ID selezionato non valido\r\n");
			return;
		}
		
		System.out.println(search(id));
	}
	

	public int searchSistema(String id) {
		int index = -1;
		
		for(Sistema sist: sistemi)
			if(id.equals(sist.getStella().getId()))
				index = sistemi.indexOf(sist);
		return index;
	}
	
	public String search(String id) {
		int index = -1;
		
		//number of underscores in order to understand if it's a star, a planet or a moon
		int counter = 0;
		for(int i = 0; i < id.length(); i++) 
			if(id.charAt(i) == '_') 
				counter ++;
			
		//star
		if (counter == 0) {
			index = searchSistema(id);
			return "" + index;				
		}
		
		
		//not a star
		if (counter == 1 || counter == 2) {
			for(Sistema sist: sistemi) {
				String risultato = sist.getStella().search(id);
				if(!risultato.equals("-1")) {
					return risultato;
				}
			}
		}
		
		//error
		if (index == -1) {
			return "Errore: Corpo celeste non trovato!";
		}
		
		return "" + index;		
	}
	
	public void calcolaCDM() {
		System.out.println("\r\nSELEZIONA IL SISTEMA DA UTILIZZARE PER IL CALCOLO");
		int index = selectSistema();
		if(index == -1) 
			return;		
		
		Coordinate cdm = sistemi.get(index).getCDM();
		
		System.out.println("Il CDM del" + sistemi.get(index).getName() + " e' " + cdm);
		
	}
	
	
	public void printAll() {
		if (sistemi.size() < 1) {
			System.out.println("Il database di pianeti � vuoto");
			return;
		}
	
		for (Sistema sist: sistemi) {
			System.out.println("  > Sistema di " + sist.getStella().getInfo());
			for(Pianeta p: sist.getStella().getPianeti()) {
				System.out.println("    > " + p.getInfo());
				for(Luna lun: p.getLune()) {
					System.out.println("      > " + lun.getInfo());
				}
				
			}
		}
	
	}

	
}
	

