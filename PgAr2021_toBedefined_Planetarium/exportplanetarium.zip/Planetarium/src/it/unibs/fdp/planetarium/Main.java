package it.unibs.fdp.planetarium;


import it.unibs.fp.mylib.InputDati;

public class Main {
	
	private static final String MENU = ""
            + "\r\n*****MENU*****\r\n"
            + "1. Crea\r\n"
            + "2. Distruggi\r\n"
            + "3. Visualizza\r\n"
            + "4. Cerca\r\n"
            + "5. Calcola il CDM\r\n"
            + "\r\n"
            + "9. Stampa tutto i sistemi"
            + "0. Esci dal programma\r\n"
            + "**********\r\n"
            + "Scelta ";
	
	private static final String SOTTOMENU1 = ""
			+ "\r\n**COSA VUOI CREARE?**\r\n"
			+ "1. Stella (=Sistema)\r\n"
			+ "2. Pianeta\r\n"
			+ "3. Luna\r\n"
			+ "\r\n"
			+ "0. Esci dal sottomenu'"
			+ "**********\r\n"
			+ "Scelta ";
	
	private static final String SOTTOMENU2 = ""
			+ "\r\n**COSA VUOI DISTRUGGERE?**\r\n"
			+ "1. Stella (=Sistema)\r\n"
			+ "2. Pianeta\r\n"
			+ "3. Luna\r\n"
			+ "\r\n"
			+ "0. Esci dal sottomenu'"
			+ "**********\r\n"
			+ "Scelta ";
				
	
	public static void main(String[] args) {
		Database db = new Database();
		int scelta;
		
		
		do {
			scelta = InputDati.leggiInteroNonNegativo(MENU);
			switch(scelta) {
			//create
			case 1: 
				scelta = InputDati.leggiInteroNonNegativo(SOTTOMENU1); 
				
				
				switch(scelta) {
				//star
				case 1: 
					db.inputSistema();					
					break;				
				//planet
				case 2: 
					db.inputPianeti();					
					break;					
				//moon
				case 3: 
					db.inputLune();	
					break;
					
				case 0: 
					scelta = -1;
					break;
						
										
				default: System.out.println("Inserisci un numero valido");
				}
				break;
				
			//destroy	
			case 2: 
				scelta = InputDati.leggiInteroNonNegativo(SOTTOMENU2); 
				
				switch(scelta) {
				//star
				case 1: 
					db.removeSistema();					
					break;				
				//planet
				case 2: 
					db.removePianeti();					
					break;					
				//moon
				case 3: 
					db.removeLuna();					
					break;
				
				case 0: 
					scelta = -1;
					break;	
			
				default: System.out.println("Inserisci un numero valido");
				}				
				break;
			
			case 3:
				db.visualizza();
				
				break;
				
			//search
			case 4:  ;
				db.ricerca();
				
				break;

			//calculate CDM
			case 5: ; 
				db.calcolaCDM();
			
				break;
			
			case 9: db.printAll();
				
				break;
			
			case 0: break;
			
			default: System.out.println("Inserisci il numero valido");			
			}
		} while(scelta != 0);
		
	
	}


}
