package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;

public class Stella extends CorpoCeleste {
	private static int counterPianeti = 0;
	private ArrayList<Pianeta> pianeti = new ArrayList<Pianeta>();
	
	public Stella(String id, Coordinate position, double weight) {
		super(id, position, weight);
	}
	
	public ArrayList<Pianeta> getPianeti() {
		return pianeti;
	}
	
	public Pianeta getPianeta(int index) {
		return pianeti.get(index);
	}
	
	@Override
	public double getMassaParziale() {
		double massparz = 0;
			
		for(Pianeta p: pianeti)  {
				massparz += p.getWeight() + p.getMassaParziale();		
		}			
			
		return massparz;
		
	}
	
	@Override
	public Coordinate getCoordinatePesateParziale() {
		Coordinate coordsPesateParz = new Coordinate(0,0);
			
		for(Pianeta p: pianeti)  {
			//somma le coordinate pesate del pianeta e quelle dei corpi collegati
			Coordinate coordsPesatePl = p.getCoordinatePesate();
			Coordinate coordsPesatePlParz = p.getCoordinatePesateParziale();
			coordsPesateParz.setX(coordsPesateParz.getX() + coordsPesatePl.getX() + coordsPesatePlParz.getX());
			coordsPesateParz.setY(coordsPesateParz.getY() + coordsPesatePl.getY() + coordsPesatePlParz.getY());
		}			
			
		return coordsPesateParz;
	}	
	
	@Override
	public void append() {
		if(pianeti.size() >= 26000) {
			System.out.println("Numero massimo di pianeti raggiunto ");
		}
		
		String id = this.getId() + "_" + "P"+ counterPianeti;
		counterPianeti ++;
		
		Coordinate position = Coordinate.input("Inserisci la posizione di" + id + "(sintassi 1.0;2.3): ");
		double weight = InputDati.leggiDoubleConMinimo("Inserisci la massa di" + id + "(min 0,5): ", 0.5);
		
		pianeti.add(new Pianeta(id, position, weight));
		
	} 

	@Override
	public void remove() {
		//Input dell'id
		String id = InputDati.leggiStringa("Inserisci l'ID del pianeta da rimuovere: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID non valido");
			return;
		}
		
		int index = -1;
		
		//searching the index of the planet 
		index = Integer.parseInt(search(id));
		
		if(index != -1) {
			pianeti.remove(index);
			System.out.println("Il pianeta � stato rimosso correttamente");
		} 
		else 
			System.out.println("Error404: Pianeta not found! ");
			
	}

	@Override
	public String toString() {
		return "Stella" + this.getId();
	}

	public String printPianeti() {
		String str = "";
		
		for(Pianeta p: pianeti) {
			str += p.getId() + " ";
		}
		
		return str;
	}
	
	@Override
	public String search(String id) {
		
		int counter = 0;
		int index = -1;
		
		for(int i = 0; i < id.length(); i++) 
			if(id.charAt(i) == '_')
				counter ++;
		
		switch(counter) {
		//planet
		case 1: 
			for(Pianeta p: pianeti) {
				if(id.equals(p.getId())) {
					index = pianeti.indexOf(p);
				}	
			}
		break;
		
		//moon
		case 2: 
			for(Pianeta p: pianeti) {
				index = Integer.parseInt(p.search(id));
				if (index != -1) {
					String risultato = "Pianeta: " + p.getId() + ",Luna: " + p.getLuna(index) + ",Index " + index;
					return risultato;//exit from 'for'
				}
			}
		break;
		
		default: System.out.println("Errore nella ricerca"); return "ERRORE";
 		}
		
		return "" + index;
	}	
	
}
