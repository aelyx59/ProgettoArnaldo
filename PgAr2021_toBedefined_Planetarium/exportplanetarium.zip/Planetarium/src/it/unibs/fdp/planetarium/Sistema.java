package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;

public class Sistema {
	private static int counterstars = 0;
	private String name;
	private Stella stella;
	private ArrayList<Coordinate> postiOccupati = new ArrayList<Coordinate>();
		
	public Sistema() {
		String id = "ST" + counterstars;
		counterstars ++;
		
		//Coordinate position = Coordinate.input("Inserisci la posizione di " + id + "(sintassi 1.0;2.3): ");
		Coordinate position = new Coordinate(0.0,0.0);
		double weight = InputDati.leggiDoubleConMinimo("Inserisci la massa di " + id + "(min 1,0): ", 1.0);
		
		//this.stella = new Stella(id, position, weight);
		this.stella = new Stella(id, new Coordinate(0.0,0.0), weight);
		this.name = "Sistema di " + id;
		this.postiOccupati.add(position);		
	}
	
	public String getName() {
		return this.name;
	}

	public Stella getStella() {
		return this.stella;
		
	}
	
	public double getMassaTotale() {
		return stella.getWeight() + stella.getMassaParziale();
			
	}
	
	public Coordinate getCoordsPesateTotale() {
		Coordinate result = new Coordinate(0,0);
		Coordinate coordsPesate = stella.getCoordinatePesate();
		Coordinate coordsPesateParz = stella.getCoordinatePesateParziale();
		
		result.setX(coordsPesate.getX() + coordsPesateParz.getX());
		result.setY(coordsPesate.getY() + coordsPesateParz.getY());
		
		
		return result;
			
	}
	
	public boolean checkPosizione(Coordinate position) {
		return this.postiOccupati.contains(position);
	}
	
	public void addPosizione(Coordinate position) {
		this.postiOccupati.add(position);
	}
	
	public String search(String id) {
		return stella.search(id);
	}
	
	
	public Coordinate getCDM() {
		Coordinate cdm = getCoordsPesateTotale();
		double massaTot = getMassaTotale();
		
		cdm.setX(cdm.getX() / massaTot);
		cdm.setY(cdm.getY() / massaTot);		
		
		return cdm;
	}
	
		
}
