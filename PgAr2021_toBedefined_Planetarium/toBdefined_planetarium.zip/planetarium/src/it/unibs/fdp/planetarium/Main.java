package it.unibs.fdp.planetarium;

import it.unibs.fp.mylib.InputDati;

public class Main {
	private static final String MENU = ""
			+ "\r\n******** MENU ********\r\n"
			+ "1. Crea\r\n"
			+ "2. Distruggi\r\n"
			+ "3. Visualizza\r\n"
			+ "4. Cerca\r\n"
			+ "5. Calcola il CDM\r\n"
			+ "\r\n"
			+ "9. Stampa i sistemi\r\n"
			+ "0. Esci dal programma\r\n"
			+ "**********************\r\n"
			+ "Scelta: ";
	
	private static final String SOTTOMENU1 = ""
			+ "\r\n** COSA VUOI CREARE? **\r\n"
			+ "1. Stella (=Sistema)\r\n"
			+ "2. Pianeta\r\n"
			+ "3. Luna\r\n"
			+ "\r\n"
			+ "0. Esci dal sottomenu'\r\n"
			+ "**********************\r\n"
			+ "Scelta: ";
	
	private static final String SOTTOMENU2 = ""
			+ "\r\n*COSA VUOI DISTRUGGERE?*\r\n"
			+ "1. Stella (=Sistema)\r\n"
			+ "2. Pianeta\r\n"
			+ "3. Luna\r\n"
			+ "\r\n"
			+ "0. Esci dal sottomenu'\r\n"
			+ "***********************\r\n"
			+ "Scelta: ";
	
	public static void main(String[] args) {
		Database db = new Database();
		
		//Stella
		db.getSistemi().add(new Sistema(new Stella("ST0", 30)));
		
		//Pianeti
		db.getSistemi().get(0).getStella().getPianeti().add(new Pianeta("ST0_P0", new Coords(0.0,-3.0), 5));
		db.getSistemi().get(0).getStella().getPianeti().add(new Pianeta("ST0_P1", new Coords(3.0,3.0), 7));
		
		//Lune
		db.getSistemi().get(0).getStella().getPianeta(0).getLune().add(new Luna("ST0_P0_LUN0", new Coords(-1.0,-4.0), 1));
		
		db.getSistemi().get(0).getStella().getPianeta(1).getLune().add(new Luna("ST0_P1_LUN1", new Coords(2.0,3.0), 2));
		db.getSistemi().get(0).getStella().getPianeta(1).getLune().add(new Luna("ST0_P1_LUN2", new Coords(4.0,4.0), 1));
		
		//db.printAll();
		
		int scelta;
		
		System.out.println("===| HELLO THERE! |===\r\n");
		
		do {
			scelta = InputDati.leggiInteroNonNegativo(MENU);
			
			switch(scelta) {
			//Crea
			case 1: 
				scelta = InputDati.leggiInteroNonNegativo(SOTTOMENU1);
				
				switch(scelta) {
				//Stella
				case 1: db.inputSistema(); break;
				//Pianeta
				case 2: db.inputPianeti(); break;
				//Luna
				case 3: db.inputLune(); break;
				//Uscita
				case 0: scelta = -1; break;	//cambio valore a scelta per non uscire dal do while
				//Errore
				default: System.out.println("Inserisci un numero valido");
				}
				break;
				
			//Distruggi
			case 2: 
				scelta = InputDati.leggiInteroNonNegativo(SOTTOMENU2);
				
				switch(scelta) {
				//Stella
				case 1: db.removeSistema(); break;
				//Pianeta
				case 2: db.removePianeta(); break;
				//Luna
				case 3: db.removeLuna(); break;
				//Uscita
				case 0: scelta = -1; break;	//cambio valore a scelta per non uscire dal do while
				//Errore
				default: System.out.println("Inserisci un numero valido");
				}
				break;
			
			//Visualizza
			case 3: db.visualizza(); break;
			
			//Cerca
			case 4: db.ricerca(); break;
				
			//Calcola CDM
			case 5: db.calcolaCDM(); break;
			
			//Stampa tutti i sistemi
			case 9: db.printAll(); break;
			
			//Uscita dal programma
			case 0: break;
			
			//Errore
			default: System.out.println("Inserisci un numero valido");
			}
		} while(scelta != 0);
		
		System.out.println("\r\nGrazie per aver utilizzato il nostro programma");
		System.out.println("Ecco il nostro PayPal: paypal.me/AlbieriLuca");
	}
}
