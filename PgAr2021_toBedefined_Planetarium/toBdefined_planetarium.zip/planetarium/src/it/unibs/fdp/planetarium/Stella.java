package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;

public class Stella extends CorpoCeleste {
	private static final String ERROR404 = "Error404: Impossibile trovare il corpo cercato";
	private static int countPianeti = 0;
	private ArrayList<Pianeta> pianeti = new ArrayList<Pianeta>();
	
	//Metodo costruttore
	public Stella(String id, double massa) {
		super(id, new Coords(0.0,0.0), massa);
	}
		
	//Getter, ritorna un l'arraylist di pianeti
	public ArrayList<Pianeta> getPianeti() {
		return pianeti;
	}
	//Getter, ritorna un pianeta dato l'indice
	public Pianeta getPianeta(int index) {
		return pianeti.get(index);
	}
	
	//Ritorna il valore del counter
	public static int getCountPianeti() {
		return countPianeti;
	}
	//Aumenta il valore del counter
	public static void incrementCountPianeti() {
		countPianeti++;
	}
	
	
	@Override
	public double getMassaParziale() {
		double massaparz = 0;
		
		for(Pianeta p: pianeti) {
			//Somma la massa del pianeta e quelle dei corpi collegati
			massaparz += p.getMassa() + p.getMassaParziale();
		}		
		
		return massaparz;
	}
	
	@Override
	//Ritorna le coordinate pesate dei corpi celesti collegati
	public Coords getCoordsPesateParziale() {
		Coords coordsPesateParz = new Coords(0,0);
		
		for(Pianeta p: pianeti) {
			//Somma le coordinate pesate del pianeta e quelle dei corpi celesti collegati
			Coords coordsPesatePl = p.getCoordsPesate();
			Coords coordsPesatePlParz = p.getCoordsPesateParziale();
			coordsPesateParz.setX(coordsPesateParz.getX() + coordsPesatePl.getX() + coordsPesatePlParz.getX());
			coordsPesateParz.setY(coordsPesateParz.getY() + coordsPesatePl.getY() + coordsPesatePlParz.getY());
		}
		
		return coordsPesateParz;
	}
	
	@Override
	public boolean append(String id, Coords pos, double massa) {
		//Controllo se abbiamo raggiunto il numero massimo di pianeti
		if(pianeti.size() >= 26000) {
			System.out.println("Numero massimo di pianeti raggiunto");
			return false;
		}
		
		//Aggiungo il pianeta all'ArrayList
		pianeti.add(new Pianeta(id, pos, massa));
		return true;
	}
	
	@Override
	public void remove() {
		//Input dell'id
		String id = InputDati.leggiStringa("Inserisci l'ID del pianeta da rimuovere: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID non valido");
			return;
		}
		
		int index = search(id);
		
		//Se � stato trovato, rimuovi il pianeta
		if(index != -1) {
			pianeti.remove(index);
			System.out.println("Il pianeta � stato rimosso correttamente");
		}
		else
			System.out.println("Error404: Pianeta not found!");
			
	}

	@Override
	public String toString() {
		return "Stella " + this.getId();
	}
	
	//Stampa l'elenco dei pianeti
	public String printPianeti() {
		String str = "";
		
		for(Pianeta p: pianeti)
			str += p.getId() + "  ";
		
		return str;
	}

	@Override
	public int search(String id) {
		int index = -1;
		
		int counterUnderscore = CorpoCeleste.getTipoCorpoCeleste(id);
		
		//Switch dei vari casi possibili
		switch(counterUnderscore) {
		//Caso pianeta
		case 1:
			for (Pianeta p: pianeti) {
				if(id.equals(p.getId())) {
					index = pianeti.indexOf(p);
				}
			}
		break;
		
		//Caso luna
		case 2:
			for (Pianeta p: pianeti) {
				index = p.search(id);
				if(index != -1)
					break;
			}
		break;
		
		//Caso errore
		default: System.out.println("Errore nella ricerca"); return -1;
		}

		return index;
	}
	
	public String searchInfo(String id) {
		String ris = ERROR404;
		
		int counterUnderscore = CorpoCeleste.getTipoCorpoCeleste(id);
		
		//Switch dei vari casi possibili
		switch(counterUnderscore) {
		//Caso pianeta
		case 1: 
			for (Pianeta p: pianeti) {
				if(id.equals(p.getId())) {
					int index = pianeti.indexOf(p);
					ris = "TROVATO!\r\n" + pianeti.get(index).getInfo();
				}
			}
		break;
		
		//Caso luna
		case 2:
			for (Pianeta p: pianeti) {
				int index = p.search(id);
				if(index != -1) {
					ris = "TROVATO!\r\nPianeta: " + p.getId() + ", Luna " + p.getLuna(index).getInfo();
				}
			}
		break;
		
		//Caso errore
		default: System.out.println("Errore nella ricerca"); return "ERRORE";
		}

		return ris;
	}
}
