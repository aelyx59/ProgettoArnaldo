package it.unibs.fdp.planetarium;

import java.util.ArrayList;

public class Sistema {
	private static int countStelle = 0;
	private String nome;
	private Stella stella;
	private ArrayList<Coords> postiOccupati = new ArrayList<Coords>();
	
	//////DEBUG ONLY
	public Sistema(Stella stella) {
		this.stella = stella;
		this.nome = "Sistema di " + stella;
		this.postiOccupati.add(new Coords(0.0,0.0));
		countStelle++;
	}
	//////
	
	/*
	//METODO SOSTITUITO
	public Sistema() {
		//INPUT DELLA STELLA
		//Assegno l'ID
		String id = "ST" + countStelle;
		countStelle++;
		
		//Prendo in input la massa, la posizione � 0;0 di default
		//Coords pos = Coords.leggiCoordinate("Inserisci la posizione di " + id + " (sintassi 1.0;2.3): ");
		double massa = InputDati.leggiDoubleConMinimo("Inserisci la massa di " + id + "(min: 1,00): ", 1.0);
		//
		
		//Assegno i valori agli attributi
		//this.stella = new Stella(id, pos, massa);
		this.stella = new Stella(id, massa);
		this.nome = "Sistema di " + id;
		this.postiOccupati.add(new Coords(0.0,0.0));
	}*/
	
	//Ritorna il valore del counter
	public static int getCountStelle() {
		return countStelle;
	}
	//Aumenta il valore del counter
	public static void incrementCountStelle() {
		countStelle++;
	}

	//Getter del nome
	public String getNome() {
		return this.nome;
	}
	
	//Getter di stella
	public Stella getStella() {
		return this.stella;
	}
	
	//Getter della massa totale del sistema
	public double getMassaTotale() {
		return stella.getMassa() + stella.getMassaParziale();
	}
	
	//Getter della massa totale del sistema
	public Coords getCoordsPesateTotale() {
		Coords result = new Coords(0,0);
		Coords coordsPesate = stella.getCoordsPesate();
		Coords coordsPesateParz = stella.getCoordsPesateParziale();
		
		result.setX(coordsPesate.getX() + coordsPesateParz.getX());
		result.setY(coordsPesate.getY() + coordsPesateParz.getY());
		
		return result;
	}
	
	
	//Controlla se la posizione � gi� presente, ritorna true se la posizione � occupata
	public boolean checkPosizione(Coords pos) {
		boolean ris = false;
		
		for(Coords c: postiOccupati) {
			if(c.equals(pos))
				ris = true;
		}
		
		return ris;
	}
	//Aggiunge la posizione all'arraylist
	public void addPosizione(Coords pos) {
		this.postiOccupati.add(pos);
	}
	
	
	//Ricerca
	public int search(String id) {
		return stella.search(id);
	}
	public String searchInfo(String id) {
		return stella.searchInfo(id);
	}
	
	//Calcolo del CDM
	public Coords getCDM() {
		Coords cdm = getCoordsPesateTotale();
		double massaTot = getMassaTotale();
		
		cdm.setX(cdm.getX() / massaTot);
		cdm.setY(cdm.getY() / massaTot);
		
		return cdm;
	}
	
}
