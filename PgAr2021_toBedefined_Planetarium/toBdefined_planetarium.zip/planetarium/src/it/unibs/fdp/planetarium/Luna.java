package it.unibs.fdp.planetarium;

public class Luna extends CorpoCeleste{
	
	public Luna(String id, Coords pos, double massa) {
		super(id, pos, massa);
	}
	
	@Override
	public boolean append(String id, Coords pos, double massa) {
		// METODO DA NON UTILIZZARE
		System.out.println("Nulla da aggiungere");
		return false;
	}
	
	@Override
	public void remove() {
		// METODO DA NON UTILIZZARE
		System.out.println("Nulla da rimuovere");
	}
	
	@Override
	public int search(String id) {
		// METODO DA NON UTILIZZARE
		return -1;
	}
	
	@Override
	public double getMassaParziale() {
		// METODO DA NON UTILIZZARE
		return 0;
	}

	@Override
	public Coords getCoordsPesateParziale() {
		// METODO DA NON UTILIZZARE
		return null;
	}

	
	@Override
	public String toString() {
		return this.getId().replace('_', '>');
		
		/* OLD
		String str = this.getId();
		
		str = str.replace('_', '>');
		
		return str;
		*/
	}
}
