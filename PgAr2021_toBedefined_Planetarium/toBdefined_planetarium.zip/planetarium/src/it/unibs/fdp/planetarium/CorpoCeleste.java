package it.unibs.fdp.planetarium;

import java.util.regex.Pattern;

//Classe astratta dei corpi celesti -> da estendere in stella, pianeta e luna
public abstract class CorpoCeleste {
	private String id;
	private Coords pos;
	private double massa;
	
	//Metodo costruttore
	public CorpoCeleste(String id, Coords pos, double massa) {
		this.id = id;
		this.pos = pos;
		this.massa = massa;
	}
	
	//Metodi astratti -> da definire
	public abstract boolean append(String id, Coords pos, double massa);
	public abstract void remove();
	public abstract String toString();
	public abstract double getMassaParziale();
	public abstract Coords getCoordsPesateParziale();
	public abstract int search(String id);
	
	//Restituisce le informazioni di un CorpoCeleste
	public String getInfo() {
		return this.id + ": massa = " + this.massa + "; pos = (" + String.format("%.2f", this.pos.getX()) + "; " + String.format("%.2f", this.pos.getY()) + ")";
	}
	
	//Restituisce le coordinate pesate
	public Coords getCoordsPesate() {
		return new Coords(pos.getX()*massa, pos.getY()*massa);
	}
	
	//Conta le occorrenze di '_' per capire se si tratta di una stella(0), un pianeta(1) o una luna(2)
	public static int getTipoCorpoCeleste(String id) {
		int counter = 0;
		for(int i=0; i<id.length(); i++)
			if(id.charAt(i) == '_')
				counter++;
		return counter;
	}
	
	//Valida una stringa passata verificando se � un possibile id  (STx_Py_LUNz)
	//Reminder: deve avere in input la stringa con il toUpper e trimmata
	public static boolean validateName(String id) {
		
		int counterUnderscore = getTipoCorpoCeleste(id);
		if(counterUnderscore>2)
			return false;
		
		//Creo delle sottostringhe all'occorrenza di "_" e le metto in parts
		String[] parts = id.split("_");
		
		//In base al numero di underscore(=> al corpo celeste) verifico il nome
		switch(parts.length) {
		//Caso stella(1)
		case 1: return validatePart(parts[0], "ST");
			
		//Caso pianeta(2)
		case 2: return validatePart(parts[0], "ST") && validatePart(parts[1], "P");
		
		//Caso luna(3)
		case 3: return validatePart(parts[0], "ST") && validatePart(parts[1], "P") && validatePart(parts[2], "LUN");
		
		//Caso errore
		default: return false;
		}
	}
	
	//EsParte: idPart=LUN0, correctString=LUN
	public static boolean validatePart(String idPart, String correctString) {
		int numIndex = -1;
		
		//Ricerco il primo numero per poter separare le lettere dai numeri
		for(int i=0; i<idPart.length() && numIndex == -1; i++)
			if(Character.isDigit(idPart.charAt(i)))
				numIndex = i;
		
		if(numIndex == -1)
			return false;
		
		String lettere = idPart.substring(0, numIndex);
		String numeri = idPart.substring(numIndex);
		//System.out.println(lettere + " " + numeri + " numindex=" + numIndex);
		
		return lettere.equals(correctString) && Pattern.matches("[0-9]+",numeri);
	}
	
	//Getters
	public String getId() {
		return id;
	}	
	public Coords getPos() {
		return pos;
	}
	public double getMassa() {
		return massa;
	}
	
}
