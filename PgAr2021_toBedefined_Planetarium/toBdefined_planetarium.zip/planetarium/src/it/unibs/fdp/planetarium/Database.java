package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;

public class Database {
	private static final String ERROR404 = "Error404: Impossibile trovare il corpo cercato";
	private ArrayList<Sistema> sistemi;
	
	//Metodo costruttore
	public Database() {
		 sistemi = new ArrayList<Sistema>();
	}
	
	//Getter, ritorna un l'arraylist di sistemi
	public ArrayList<Sistema> getSistemi() {
		return sistemi;
	}
	//Getter, ritorna un sistema dato l'indice
	public Sistema getSistema(int index) {
		return sistemi.get(index);
	}
	
	
	//Stampa l'elenco delle stelle (tipo toString() )
	public String printStelle() {
		String str = "";
		for(Sistema sist: sistemi)
			str += sist.getStella().getId() + "  ";
		
		return str;
	}
	
	
	//Input
	public void inputSistema() {
		//INPUT DELLA STELLA
		//Assegno l'ID
		String id = "ST" + Sistema.getCountStelle();
		Sistema.incrementCountStelle();
		
		System.out.println("\r\n> CREAZIONE DI " + id);
		
		//Prendo in input la massa, la posizione � 0;0 di default
		double massa = InputDati.leggiDoubleConMinimo("Inserisci la massa (min: 1,00): ", 1.0);
				
		//Aggiungo all'elenco dei sistemi un nuovo sistema contenente la nuova stella
		sistemi.add(new Sistema(new Stella(id, massa)));
		//printStelle();
		System.out.println("\r\nSistema e stella creati con successo\r\n");
	}
	
	public void inputPianeti() {
		int index = selectSistema();
		//Se il sistema non viene selezionato esco
		if(index == -1)
			return;
		
		//Assegno l'ID
		String id = this.getSistema(index).getStella().getId() + "_" + "P" + Stella.getCountPianeti();
		Stella.incrementCountPianeti();
		
		System.out.println("\r\n> CREAZIONE DI " + id);
		
		//Prendo in input la posizione finch� � libera
		Coords pos = Coords.leggiCoordinate("Inserisci la posizione (sintassi 1.0;2.3): ");;
		while(this.getSistema(index).checkPosizione(pos)) {
			System.out.println("Posizione occupata! Inseriscine una valida");
			pos = Coords.leggiCoordinate("Inserisci la posizione (sintassi 1.0;2.3): ");
		}
		//Una volta ottenuta una posizione valida la aggiungo all'arraylist
		this.getSistema(index).addPosizione(pos);
		//Input della massa
		double massa = InputDati.leggiDoubleConMinimo("Inserisci la massa (min: 0,50): ", 0.5);
		
		//Tento l'append, se abbiamo raggiunto il limite viene ritornato false
		if(sistemi.get(index).getStella().append(id, pos, massa))
			System.out.println("\r\nPianeta creato con successo\r\n");
		else System.out.println("\r\nLimite di pianeti raggiunto!\r\n");
	}
	
	public void inputLune() {
		int indexSistema = selectSistema();
		//Se il sistema non viene selezionato esco
		if(indexSistema == -1)
			return;
		
		int indexPianeta = selectPianeta(indexSistema);
		//Se il pianeta non viene selezionato esco
		if(indexPianeta == -1)
			return;
		
		//Assegno l'ID
		String id = this.getSistema(indexSistema).getStella().getPianeta(indexPianeta).getId() + "_" + "LUN" + Pianeta.getCountLune();
		Pianeta.incrementCountLune();
		
		System.out.println("\r\n> CREAZIONE DI " + id);
		
		//Prendo in input la posizione finch� � libera
		Coords pos = Coords.leggiCoordinate("Inserisci la posizione (sintassi 1.0;2.3): ");;
		while(this.getSistema(indexSistema).checkPosizione(pos)) {
			System.out.println("Posizione occupata! Inseriscine una valida");
			pos = Coords.leggiCoordinate("Inserisci la posizione (sintassi 1.0;2.3): ");
		}
		//Una volta ottenuta una posizione valida la aggiungo all'arraylist
		this.getSistema(indexSistema).addPosizione(pos);
		//Input della massa
		double massa = InputDati.leggiDoubleConMinimo("Inserisci la massa (min: 0,25): ", 0.25);
		
		//Tento l'append, se abbiamo raggiunto il limite viene ritornato false
		if(sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).append(id, pos, massa))
			System.out.println("\r\nLuna creata con successo\r\n");
		else System.out.println("\r\nLimite di lune raggiunto!\r\n");
	}
	
	
	//Remove
	public void removeSistema() {
		int index = selectSistema();
		if(index == -1)
			return;
		
		sistemi.remove(index);
		
		System.out.println("\r\nStella distrutta con successo\r\n");
	}
	
	public void removePianeta() {
		int indexSistema = selectSistema();
		//Se il sistema non viene selezionato esco
		if(indexSistema == -1)
			return;
		
		int indexPianeta = selectPianeta(indexSistema);
		//Se il pianeta non viene selezionato esco
		if(indexPianeta == -1)
			return;
		
		sistemi.get(indexSistema).getStella().getPianeti().remove(indexPianeta);
		
		System.out.println("\r\nPianeta distrutto con successo\r\n");
	}
	
	public void removeLuna() {
		int indexSistema = selectSistema();
		//Se il sistema non viene selezionato esco
		if(indexSistema == -1)
			return;

		int indexPianeta = selectPianeta(indexSistema);
		//Se il pianeta non viene selezionato esco
		if(indexPianeta == -1)
			return;
		
		int indexLuna = selectLuna(indexSistema, indexPianeta);
		//Se la luna non viene selezionata esco
		if(indexLuna == -1)
			return;
		
		sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).getLune().remove(indexLuna);
		
		System.out.println("\r\nLuna distrutta con successo\r\n");
	}
	

	//Select
	//Ritorna l'indice di un sistema preso in input da tastiera
	public int selectSistema() {
		//Controllo che esista almeno un sistema
		if(sistemi.size()<1){
			System.out.println("Devi creare una stella!\r\n");
			return -1;
		}

		System.out.println("> Scegli una stella tra le seguenti: " + printStelle());
		
		//Prendo l'ID finch� non � valido e rappresenta il corpo celeste necessario
		String id = inputId();
		while(id.equals("-1") || CorpoCeleste.getTipoCorpoCeleste(id) != 0){
			if(!id.equals("-1"))
				System.out.println("Il corpo celeste selezionato non e' una stella");
			id = inputId();
		}		
		
		int index = search(id);
		if(index == -1) {
			System.out.println("Stella non trovata!\r\n");
			return -1;
		}
		return index;
	}
	
	//Ritorna l'indice di un pianeta preso in input da tastiera, dato l'indice del sistema
	public int selectPianeta(int indexSistema) {
		Stella st = sistemi.get(indexSistema).getStella();
		
		//Controllo che esista almeno un pianeta
		if(st.getPianeti().size()<1){
			System.out.println("Devi creare un pianeta!\r\n");
			return -1;
		}
		
		System.out.println("> Scegli un pianeta tra i seguenti: " + st.printPianeti());
		
		//Prendo l'ID finch� non � valido e rappresenta il corpo celeste necessario
		String id = inputId();
		while(id.equals("-1") || CorpoCeleste.getTipoCorpoCeleste(id) != 1){
			if(!id.equals("-1"))
				System.out.println("Il corpo celeste selezionato non e' un pianeta");
			id = inputId();
		}
		
		//Ricerco il pianeta
		int index = st.search(id);
		if(index == -1) {
			System.out.println("Pianeta non trovato!\r\n");
			return -1;
		}		
		
		return index;
	}
	
	//Ritorna l'indice di una luna preso in input da tastiera, dato l'indice del sistema e del pianeta
	public int selectLuna(int indexSistema, int indexPianeta) {
		Pianeta p = sistemi.get(indexSistema).getStella().getPianeta(indexPianeta);
		
		//Controllo che esista almeno una luna
		if(p.getLune().size()<1){
			System.out.println("Devi creare una luna!\r\n");
			return -1;
		}
		
		System.out.println("> Scegli una luna tra le seguenti: " + p.printLune());
		
		//Prendo l'ID finch� non � valido e rappresenta il corpo celeste necessario
		String id = inputId();
		while(id.equals("-1") || CorpoCeleste.getTipoCorpoCeleste(id) != 2){
			if(!id.equals("-1"))
				System.out.println("Il corpo celeste selezionato non e' una luna");
			id = inputId();
		}	
		
		//Ricerco la luna
		int index = p.search(id);
		if(index == -1) {
			System.out.println("Luna non trovata!\r\n");
			return -1;
		}		
		
		return index;
	}
	
	public String inputId() {
		//Input dell'ID e validazione
		String id = InputDati.leggiStringa("Scelta: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID selezionato non valido\r\n");
			return "" + -1;
		}
		return id;
	}
	
	
	//Metodo per la visualizzazione dei corpi celesti
	//NUMs: Stella(1), Pianeta(2), Luna(3), Uscita(0)
	public void visualizza() {
		int selezionato = 1;
		int scelta = 0;
		int indexSistema = -1;
		int indexPianeta = -1;
		int indexLuna = -1;
		
		System.out.println("\r\n> VISUALIZZAZIONE DEI SISTEMI"); 
		
		do {
			System.out.println(); //A capo
			switch(selezionato) {
			//Stella
			case 1:
				indexSistema = selectSistema();
				if(indexSistema == -1) break; //non trovato
				System.out.println("> " + sistemi.get(indexSistema).getStella().getInfo());
				selezionato = 2;
				break;
			//Pianeta
			case 2:
				if(indexSistema != -1) {
					indexPianeta = selectPianeta(indexSistema);
					if(indexPianeta == -1) break; //non trovato
					System.out.println("> " + sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).getInfo());
					selezionato = 3;
				}
				break;
			//Luna
			case 3:
				if(indexSistema != -1 && indexPianeta != -1) {
					indexLuna = selectLuna(indexSistema, indexPianeta);
					if(indexLuna == -1) break; //non trovato
					System.out.println("> " + sistemi.get(indexSistema).getStella().getPianeta(indexPianeta).getLuna(indexLuna).getInfo());
				}
				break;
			//Uscita
			case 0: break;
			//Errore
			default: System.out.println("ERRORE");
			}
			
			//Menu di scelta
			do {
				scelta = InputDati.leggiIntero("\r\n**Cosa vuoi fare (torna al menu[0], indietro[1], prosegui[any other number]): ");
				if(scelta == 1 && selezionato>1)
					selezionato--;
			} while(scelta == 1);
	
		} while(scelta != 0);
	}
	
	//Ricerca
	public void ricerca() {
		System.out.println("\r\n> INSERISCI L'ID DEL CORPO CELESTE DA RICERCARE");
		
		//Input dell'ID e validazione
		String id = InputDati.leggiStringa("Scelta: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID selezionato non valido\r\n");
			return;
		}
		
		System.out.println(searchInfo(id));
	}
	
	//Metodo per la ricerca, se � una stella cerca, altrimenti richiama sulla stella la ricerca
	public int search(String id) {
		int index = -1;
		
		//Conto il numero di underscore per capire se � una stella(0), un pianeta(1) o una luna(2)
		int counter = 0;
		for(int i=0; i<id.length(); i++)
			if(id.charAt(i) == '_')
				counter++;
		
		//Controlli dei vari casi possibili
		//Caso stella
		if(counter == 0) { 
			for(Sistema sist: sistemi) {
				if(id.equals(sist.getStella().getId())) {
					index = sistemi.indexOf(sist);
					break;
				}
			}
		}
		
		//Caso non stella
		if(counter == 1 || counter == 2) {
			for (Sistema sist: sistemi) {
				index = sist.getStella().search(id);
				if(index != -1)
					break;
			}
		}
		
		return index;
	}
	public String searchInfo(String id) {
		String ris = ERROR404;
		
		int counterUnderscore = CorpoCeleste.getTipoCorpoCeleste(id);
		
		
		//Controlli dei vari casi possibili
		//Caso stella
		if(counterUnderscore == 0) { 
			int index = search(id);
			if(index != -1)
				ris = sistemi.get(index).getStella().getInfo();
		}
		
		//Caso non stella
		if(counterUnderscore == 1 || counterUnderscore == 2) {
			for (Sistema sist: sistemi) {
				ris = sist.getStella().searchInfo(id);
				if(!ris.equals(ERROR404))
					break;
			}
		}

		return ris;
	}
	
	//Metodo per il calcolo del CDM, richiama il metodo sul sistema preso in input
	public void calcolaCDM() {
		System.out.println("\r\n> SELEZIONA IL SISTEMA DA UTILIZZARE PER IL CALCOLO");
		int index = selectSistema();
		if(index == -1)
			return;
		
		Coords cdm = sistemi.get(index).getCDM();
		
		System.out.println("Il CDM del " + sistemi.get(index).getNome() + " e' " + cdm);
	}
	
	
	//Stampa tutti i sistemi
	public void printAll() {
		if(sistemi.size()<1) {
			System.out.println("Il database di pianeti � vuoto");
			return;
		}
		
		for(Sistema sist: sistemi) {
			System.out.println("> Sistema di " + sist.getStella().getInfo());
			for(Pianeta p: sist.getStella().getPianeti()) {
				System.out.println("    > " + p.getInfo());
				for(Luna lun: p.getLune()) {
					System.out.println("        > " + lun.getInfo());
				}
				System.out.println("");
			}
		}
	}
}
