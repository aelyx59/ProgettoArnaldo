package it.unibs.fdp.planetarium;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;

public class Pianeta extends CorpoCeleste{
	private static int countLune = 0;
	private ArrayList<Luna> lune = new ArrayList<Luna>();
	
	//Metodo costruttore
	public Pianeta(String id, Coords pos, double massa) {
		super(id, pos, massa);
	}
	
	//Getter, ritorna l'arraylist di lune
	public ArrayList<Luna> getLune() {
		return lune;
	}
	//Getter, ritorna una luna dato l'indice
	public Luna getLuna(int index) {
		return lune.get(index);
	}
	
	//Ritorna il valore del counter
	public static int getCountLune() {
		return countLune;
	}
	//Aumenta il valore del counter
	public static void incrementCountLune() {
		countLune++;
	}
	
	@Override
	//Ritorna la massa dei corpi celesti collegati
	public double getMassaParziale() {
		double massaparz = 0;
		
		for(Luna lun: lune) {
			massaparz += lun.getMassa();
		}
		
		return massaparz;
	}
	
	@Override
	//Ritorna le coordinate pesate dei corpi celesti collegati
	public Coords getCoordsPesateParziale() {
		Coords coordsPesateParz = new Coords(0,0);
		
		for(Luna lun: lune) {
			//Somma le coordinate pesate dei corpi celesti collegati
			Coords coordsPesateLun = lun.getCoordsPesate();
			coordsPesateParz.setX(coordsPesateParz.getX() + coordsPesateLun.getX());
			coordsPesateParz.setY(coordsPesateParz.getY() + coordsPesateLun.getY());
		}
		
		return coordsPesateParz;
	}
	
	@Override
	public boolean append(String id, Coords pos, double massa) {
		//Controllo se abbiamo raggiunto il numero massimo di lune
		if(lune.size() >= 5000) {
			System.out.println("Numero massimo di lune raggiunto");
			return false;
		}
		
		//Aggiungo la luna all'ArrayList
		lune.add(new Luna(id, pos, massa));
		return true;
	}
	
	@Override
	public void remove() {
		//Input dell'id
		String id = InputDati.leggiStringa("Inserisci l'ID della luna da rimuovere: ").toUpperCase().trim();
		if(CorpoCeleste.validateName(id) == false) {
			System.out.println("ID non valido");
			return;
		}
		
		int index = -1;
		
		//Ricerca l'indice della luna
		index = search(id);
		
		//Se � stata trovata, rimuovi la luna
		if(index != -1) {
			lune.remove(index);
			System.out.println("La luna � stata rimossa correttamente");
		}
		else
			System.out.println("Error404: Luna not found!");
	}

	@Override
	public String toString() {
		String str = "";
		
		for (Luna lun: lune) {
			str += lun.getId() + " in posizione " + lun.getPos() + "\n";
		}
		
		return str;
	}
	
	//Stampa l'elenco delle lune
	public String printLune() {
		String str = "";
		
		for(Luna lun: lune)
			str += lun.getId() + "  ";
		
		return str;
	}

	@Override
	public int search(String id) {
		int index = -1;
		for (Luna lun: lune) {
			if(id.equals(lun.getId())) {
				index = lune.indexOf(lun);
			}
		}
		return index;
	}
}
